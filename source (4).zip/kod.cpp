// Joanna Szewczyk
#include <string>

std::string FormatujNapis(std::string napis_wczytywany, std::string pierwsze_literki_i_spacje, std::string drugie_literki_i_spacje, std::string trzecie_literki_i_spacje)
{
    std::string string_zwracany = "";
    int size = napis_wczytywany.size();
    int cyferka = 0; // 48 do 57 to cyferki
    int j = 0;
    int ile_razy = 0;
    int znak5 = 0;
    for (int i = 0; i < size; i++)
    {
        if (napis_wczytywany[i] == '{')
        {
            if (napis_wczytywany[i + 3] == '0')
            {
                ile_razy = 0;
            }
            if (napis_wczytywany[i + 3] == '1')
            {
                ile_razy = 1;
            }
            if (napis_wczytywany[i + 3] == '2')
            {
                ile_razy = 2;
            }
            if (napis_wczytywany[i + 3] == '3')
            {
                ile_razy = 3;
            }
            if (napis_wczytywany[i + 3] == '4')
            {
                ile_razy = 4;
            }
            if (napis_wczytywany[i + 3] == '5')
            {
                ile_razy = 5;
            }
            if (napis_wczytywany[i + 3] == '6')
            {
                ile_razy = 6;
            }
            if (napis_wczytywany[i + 3] == '7')
            {
                ile_razy = 7;
            }
            if (napis_wczytywany[i + 3] == '8')
            {
                ile_razy = 8;
            }
            if (napis_wczytywany[i + 3] == '9')
            {
                ile_razy = 9;
            }

            if (napis_wczytywany[i + 5] == '0')
            {
                znak5 = 0;
            }
            if (napis_wczytywany[i + 5] == '1')
            {
                znak5 = 1;
            }
            if (napis_wczytywany[i + 5] == '2')
            {
                znak5 = 2;
            }
            if (napis_wczytywany[i + 5] == '3')
            {
                znak5 = 3;
            }
            if (napis_wczytywany[i + 5] == '4')
            {
                znak5 = 4;
            }
            if (napis_wczytywany[i + 5] == '5')
            {
                znak5 = 5;
            }
            if (napis_wczytywany[i + 5] == '6')
            {
                znak5 = 6;
            }
            if (napis_wczytywany[i + 5] == '7')
            {
                znak5 = 7;
            }
            if (napis_wczytywany[i + 5] == '8')
            {
                znak5 = 8;
            }
            if (napis_wczytywany[i + 5] == '9')
            {
                znak5 = 9;
            }
            if (napis_wczytywany[i + 1] == 'p')
            {

                while (ile_razy > cyferka)
                {
                    string_zwracany = string_zwracany + napis_wczytywany[i + 5];
                    ile_razy--;
                }
                i += 6;
            }
            else if (napis_wczytywany[i + 1] == 'u')
            {
                //  j = napis_wczytywany[i + 3];
                i += 4 + ile_razy;
            }
            else if (napis_wczytywany[i + 1] == 'U')
            {
                string_zwracany.resize(string_zwracany.size() - ile_razy);
                i += 4;
            }
            else if (napis_wczytywany[i + 1] == 'w')
            {
                i += 4;
                if (ile_razy == 1)
                {
                    string_zwracany = string_zwracany + pierwsze_literki_i_spacje;
                }
                else if (ile_razy == 2)
                {
                    string_zwracany = string_zwracany + drugie_literki_i_spacje;
                }
                else if (ile_razy == 3)
                {
                    string_zwracany = string_zwracany + trzecie_literki_i_spacje;
                }
            }
            else if (napis_wczytywany[i + 1] == 'W')
            {
                if (ile_razy == 1)
                {
                    if (znak5 > pierwsze_literki_i_spacje.size())
                    {
                        string_zwracany = string_zwracany + pierwsze_literki_i_spacje;
                        for (int j = 0; j < (znak5 - pierwsze_literki_i_spacje.size()); j++)
                        {
                            string_zwracany = string_zwracany + " ";
                        }
                    }
                    else
                    {
                        for (int j = 0; j < (znak5); j++)
                        {
                            string_zwracany = string_zwracany + pierwsze_literki_i_spacje[j];
                        }
                    }
                }
                else if (ile_razy == 2)
                {
                    if (znak5 > drugie_literki_i_spacje.size())
                    {
                        string_zwracany = string_zwracany + drugie_literki_i_spacje;
                        for (int j = 0; j < (znak5 - drugie_literki_i_spacje.size()); j++)
                        {
                            string_zwracany = string_zwracany + " ";
                        }
                    }
                    else
                    {
                        for (int j = 0; j < (znak5); j++)
                        {
                            string_zwracany = string_zwracany + drugie_literki_i_spacje[j];
                        }
                    }
                    // napis_wczytywany = napis_wczytywany + drugie_literki_i_spacje;
                }
                else if (ile_razy == 3)
                {
                    if (znak5 > trzecie_literki_i_spacje.size())
                    {
                        string_zwracany = string_zwracany + trzecie_literki_i_spacje;
                        for (int j = 0; j < (znak5 - trzecie_literki_i_spacje.size()); j++)
                        {
                            string_zwracany = string_zwracany + " ";
                        }
                    }
                    else
                    {
                        for (int j = 0; j < (znak5); j++)
                        {
                            string_zwracany = string_zwracany + trzecie_literki_i_spacje[j];
                        }
                    }
                    // napis_wczytywany = napis_wczytywany + trzecie_literki_i_spacje;
                }
                i += 6;
            }
        }
        else
        {
            string_zwracany = string_zwracany + napis_wczytywany[i];
        }
    }

    return string_zwracany;
}
// jeszcze chyba skrajny orzypadek ze jako ostatnie
std::string NajwiekszeSlowo(std::string slowko)
{
    int indeks_najwiekszego_slowka = 0;
    std::string nasze_najwieksze = "";
    int size = slowko.size();

    for (int i = 1; i < size; i++)
    {
        if (slowko[i - 1] == ' ')
        {
            if (slowko[i] > slowko[indeks_najwiekszego_slowka])
            {
                indeks_najwiekszego_slowka = i;
            }
            else
            {
                if (slowko[i] == slowko[indeks_najwiekszego_slowka])
                {
                    if (slowko[i + 1] > slowko[indeks_najwiekszego_slowka + 1])
                    {
                        indeks_najwiekszego_slowka = i;
                    }
                    else
                    {
                        if (slowko[i + 1] == slowko[indeks_najwiekszego_slowka + 1])
                        {
                            if (slowko[i + 2] > slowko[indeks_najwiekszego_slowka + 2])
                            {
                                indeks_najwiekszego_slowka = i;
                            }
                            else
                            {
                                if (slowko[i + 2] == slowko[indeks_najwiekszego_slowka + 2])
                                {
                                    if (slowko[i + 3] > slowko[indeks_najwiekszego_slowka + 3])
                                    {
                                        indeks_najwiekszego_slowka = i;
                                    }
                                    else
                                    {
                                        if (slowko[i + 3] == slowko[indeks_najwiekszego_slowka + 3])
                                        {
                                            if (slowko[i + 4] > slowko[indeks_najwiekszego_slowka + 4])
                                            {
                                                indeks_najwiekszego_slowka = i;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    std::string hehehe = "        ";
    while (slowko[indeks_najwiekszego_slowka] != hehehe[0])
    {
        if (indeks_najwiekszego_slowka == size)
        {
            break;
        }
        nasze_najwieksze = nasze_najwieksze + slowko[indeks_najwiekszego_slowka];
        indeks_najwiekszego_slowka++;
    }

    return nasze_najwieksze;
}

std::string NormalizujNapis(std::string napis)
{
    std::string znormalizowany = "";
    int i = 0;
    int size = napis.size();
    std::string spacja = " ";
    std::string przecinek = ",";
    std::string kropka = ".";
    char pusty = '\0';
    int pomocniczy = 0;
    int pomocniczy2 = (size - 1);

    while (napis[pomocniczy] == spacja[0])
    {

        pomocniczy++;
        i++;
    }

    while (i < napis.size())
    {
        while (napis[i] == spacja[0])
        {
            if (napis[i + 1] == spacja[0] || napis[i + 1] == przecinek[0] || napis[i + 1] == kropka[0] || i + 1 == size)
            {
                i++;
            }

            else
            {
                break;
            }
        }

        if ((napis[i] == kropka[0] || napis[i] == przecinek[0]) && napis[i + 1] != spacja[0] && i != size - 1)
        {
            znormalizowany = znormalizowany + napis[i];
            znormalizowany = znormalizowany + spacja[0];
            i++;
        }

        if (i != size)
        {
            znormalizowany = znormalizowany + napis[i];
            i++;
        }
    }
    return znormalizowany;
}
std::string UsunSlowo(std::string nasz_string, int integer)
// pamietac zeby zobaczyc jesli checmy usunac wiekesze slowo niz ilosc slow
{
    int ilosc_spacji = 0;
    std::string pusty_string;
    std::string spacja1 = " ";
    int size1 = nasz_string.size();
    for (int i = 0; i < size1; i++)
    {
        if (nasz_string[i] == spacja1[0])
        {
            ilosc_spacji++;
        }
    }

    if (ilosc_spacji == 0 && integer == 1)
    {
        return pusty_string;
    }
    else
    {
        if (nasz_string == "" || nasz_string == " ")
        {
            return "";
        }
        else
        {
            int size = nasz_string.size();
            int ile_slow = 0;
            std::string spacja = " ";
            if (nasz_string[0] != spacja[0])
            {
                ile_slow = 1;
            }

            for (int i = 0; i < (size - 1); i++)
            {
                if ((nasz_string[i] == spacja[0]) && (nasz_string[i + 1] != spacja[0]))
                {
                    ile_slow++;
                }
            }

            if (integer > ile_slow)
            {
                return nasz_string;
            }
            else
            {

                int i = 0;
                std::string slowo_po_usunieciu = "";
                std::string puste_slowo = "";
                char pusty_char = '\0';
                int pomocnicza = 0;
                int poczatek_szukanego_napisu = 0;
                std::string znormalizowany;

                int indeks = 0;
                int ile_mamy_slow = 0;
                if (nasz_string[0] != spacja[0])
                {
                    ile_mamy_slow = 1;
                }
                for (int i = 0; i < size; i++)
                {

                    if ((nasz_string[i] == spacja[0]) && (nasz_string[i + 1] != spacja[0]))
                    {
                        ile_mamy_slow++;
                    }

                    if (ile_mamy_slow == integer)
                    {
                        break;
                    }
                    indeks++;
                }
                i = 0;
                while (i < indeks)
                {
                    slowo_po_usunieciu = slowo_po_usunieciu + nasz_string[i];
                    i++;
                }
                i++;
                while (nasz_string[i] != spacja[0])
                {
                    i++;
                }
                while (i < size)
                {
                    slowo_po_usunieciu = slowo_po_usunieciu + nasz_string[i];
                    i++;
                } /*
                 int i = 0;
                 int j = 1;
                 int indeks;
                 if (nasz_string[0] != spacja[0])
                 {
                     for (int i = 0; i < nasz_string.size(); i++)
                     {
                         while (j < integer)
                         { // zmienimy j = 0 gdy zacyna sie spacja

                             if (nasz_string[i] == spacja[0] && nasz_string[i + 1] != spacja[0])
                             {
                                 indeks = j;
                                 j++;
                             }
                         }
                         //  for (int i = 0; i < (nasz_string.size() - 1); i++)
                     }
                 }

                 else if (nasz_string[0] == spacja[0])
                 {
                     j = 0;

                     for (int i = 0; i < nasz_string.size(); i++)
                     {
                         while (j < integer)
                         { // zmienimy j = 0 gdy zacyna sie spacja

                             if (nasz_string[i] == spacja[0] && nasz_string[i + 1] != spacja[0])
                             {
                                 indeks = j;
                                 j++;
                             }
                         }
                     }

                     //  for (int i = 0; i < (nasz_string.size() - 1); i++)
                 }

                 int l = 0;
                 int k = 0;
                 while (l < indeks)
                 {
                     // j+1
                     puste_slowo[l] = nasz_string[l];
                     l++;
                     k++;
                 }

                 while (nasz_string[l] != spacja[0])
                 {

                     l++;
                 }
                 while (l < nasz_string.size())
                 {

                     puste_slowo[k] = nasz_string[l];
                     l++;
                 }

                 return puste_slowo;
                 */
                return slowo_po_usunieciu;
            }
        }
    }
}