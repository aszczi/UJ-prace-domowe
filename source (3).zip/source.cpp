// Joanna Szewczyk


struct Skladowe
{
    bool nasz_bool;
    unsigned char nasz_uchar;
    float nasz_float;
};

struct Dane
{
    int liczba;
    std::string napis; // moze = "", a moze nie
    std::string znak;

    Skladowe skladowa1;
    Skladowe skladowa2;
    Skladowe skladowa3;
    Skladowe skladowa4;

 
};


struct ZliczaneLiczby
{
    int liczba;
    int ilosc;
};

bool ladujDaneZliczajace(std::fstream &plik, ZliczaneLiczby &data1)
{
    plik >> data1.liczba;
    plik >> data1.ilosc;

    return !plik.eof();
}

void ZapiszDaneZliczajace(std::fstream &plik, ZliczaneLiczby data1)
{
    plik << data1.liczba << " ";
    plik << data1.ilosc << "\n";
}

bool ladujDane(std::istream &plik, Dane &data1)
{
    std::string pomocniczy_string;
    int pomocniczy = 0;
    plik >> data1.liczba;
    plik.ignore(2, '\n');
    getline(plik, pomocniczy_string); // pobieramy 2 dana
    data1.napis = pomocniczy_string;
    getline(plik, pomocniczy_string);
    data1.znak = pomocniczy_string; // pobieramy 3 dana
    plik >> data1.skladowa1.nasz_bool;
    plik >> pomocniczy;
    data1.skladowa1.nasz_uchar = pomocniczy;
    (plik >> data1.skladowa1.nasz_float);
    //  getline(plik, pomocniczy_string);
    plik >> data1.skladowa2.nasz_bool;
    plik >> pomocniczy;
    data1.skladowa2.nasz_uchar = pomocniczy;
    (plik >> data1.skladowa2.nasz_float);
    //  getline(plik, pomocniczy_string);
    plik >> data1.skladowa3.nasz_bool;
    plik >> pomocniczy;
    data1.skladowa3.nasz_uchar = pomocniczy;
    (plik >> data1.skladowa3.nasz_float);
    //  getline(plik, pomocniczy_string);
    plik >> data1.skladowa4.nasz_bool;
    plik >> pomocniczy;
    data1.skladowa4.nasz_uchar = pomocniczy;
    (plik >> data1.skladowa4.nasz_float);
    //   getline(plik, pomocniczy_string);

    return !plik.eof();
}

void ZapiszDane(std::ostream &plik, Dane data1)
{
    std::string pomocniczy_string;
    int pomoczniczy;
    plik << data1.liczba << "\n";
    plik << data1.napis << "\n";
    plik << data1.znak << "\n";
    //  ---
    plik << data1.skladowa1.nasz_bool << " ";
    pomoczniczy = data1.skladowa1.nasz_uchar;
    plik << pomoczniczy << " ";
    plik << data1.skladowa1.nasz_float << "\n";
    //  ---
    plik << data1.skladowa2.nasz_bool << " ";
    pomoczniczy = data1.skladowa2.nasz_uchar;
    plik << pomoczniczy << " ";
    plik << data1.skladowa2.nasz_float << "\n";
    //  ---
    plik << data1.skladowa3.nasz_bool << " ";
    pomoczniczy = data1.skladowa3.nasz_uchar;
    plik << pomoczniczy << " ";
    plik << data1.skladowa3.nasz_float << "\n";
    //  ---
    plik << data1.skladowa4.nasz_bool << " ";
    pomoczniczy = data1.skladowa4.nasz_uchar;
    plik << pomoczniczy << " ";
    plik << data1.skladowa4.nasz_float << "\n";
}

bool porownajDane(Dane data1, Dane data2)
{
    return ((data1.liczba == data2.liczba) &&
            (data1.napis == data2.napis) &&
            (data1.znak == data2.znak) &&
            (data1.skladowa1.nasz_bool == data2.skladowa1.nasz_bool) &&
            (data1.skladowa1.nasz_float == data2.skladowa1.nasz_float) &&
            (data1.skladowa1.nasz_uchar == data2.skladowa1.nasz_uchar) &&
            (data1.skladowa2.nasz_bool == data2.skladowa2.nasz_bool) &&
            (data1.skladowa2.nasz_float == data2.skladowa2.nasz_float) &&
            (data1.skladowa2.nasz_uchar == data2.skladowa2.nasz_uchar) &&
            (data1.skladowa3.nasz_bool == data2.skladowa3.nasz_bool) &&
            (data1.skladowa3.nasz_float == data2.skladowa3.nasz_float) &&
            (data1.skladowa3.nasz_uchar == data2.skladowa3.nasz_uchar) &&
            (data1.skladowa4.nasz_bool == data2.skladowa4.nasz_bool) &&
            (data1.skladowa4.nasz_float == data2.skladowa4.nasz_float) &&
            (data1.skladowa4.nasz_uchar == data2.skladowa4.nasz_uchar));
}

void SortInt(std::string nazwa_pliku, std::string plik_pomocniczy1, std::string plik_pomocniczy2)
{
    bool zamiana;

    std::fstream plik;
    std::fstream pomocniczy1;

    Dane sprawdzana;
    Dane porownywana;

    do
    {
        zamiana = false;

        plik.open(nazwa_pliku.c_str(), std::fstream::in);
        pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::out | std::fstream::trunc);

        if (ladujDane(plik, sprawdzana))
        {
            while (ladujDane(plik, porownywana))
            {
                if (sprawdzana.liczba > porownywana.liczba)
                {
                    ZapiszDane(pomocniczy1, porownywana);
                    zamiana = true;
                }
                else
                {
                    ZapiszDane(pomocniczy1, sprawdzana);
                    sprawdzana = porownywana;
                }
            }

            ZapiszDane(pomocniczy1, sprawdzana);
        }

        plik.close();
        pomocniczy1.close();

        if (zamiana)
        {
            // otwieramy, ĹĽeby byÄ‡ na poczÄ…tku plikĂłw
            pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::in);
            plik.open(nazwa_pliku.c_str(), std::fstream::out | std::fstream::trunc);

            std::string bufor;

            while (std::getline(pomocniczy1, bufor))
            {
                plik << bufor << '\n';
            }

            plik.close();
            pomocniczy1.close();
        }

    } while (zamiana);
}

void SortString(std::string nazwa_pliku, std::string plik_pomocniczy1, std::string plik_pomocniczy2)
{
    bool zamiana;

    std::fstream plik;
    std::fstream pomocniczy1;

    Dane sprawdzana;
    Dane porownywana;

    do
    {
        zamiana = false;

        plik.open(nazwa_pliku.c_str(), std::fstream::in);
        pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::out | std::fstream::trunc);

        if (ladujDane(plik, sprawdzana))
        {
            while (ladujDane(plik, porownywana))
            {
                if (sprawdzana.napis > porownywana.napis)
                {
                    ZapiszDane(pomocniczy1, porownywana);
                    zamiana = true;
                }
                else
                {
                    ZapiszDane(pomocniczy1, sprawdzana);
                    sprawdzana = porownywana;
                }
            }

            ZapiszDane(pomocniczy1, sprawdzana);
        }

        plik.close();
        pomocniczy1.close();

        if (zamiana)
        {
            // otwieramy, ĹĽeby byÄ‡ na poczÄ…tku plikĂłw
            pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::in);
            plik.open(nazwa_pliku.c_str(), std::fstream::out | std::fstream::trunc);

            std::string bufor;

            while (std::getline(pomocniczy1, bufor))
            {
                plik << bufor << '\n';
            }

            plik.close();
            pomocniczy1.close();
        }

    } while (zamiana);
}

void SymmetricDifference(std::string nazwa_pliku, std::string plik_pomocniczy1, std::string plik_pomocniczy2)
{
    std::fstream sprawdzCzyPusty(plik_pomocniczy1.c_str(), std::fstream::in | std::fstream::out | std::fstream::ate);
    if (sprawdzCzyPusty.tellg() == 0)
    {
        sprawdzCzyPusty.close();
        return;
    }
    sprawdzCzyPusty.close();

    std::string linia1Wejscie;
    std::string linia2Wejscie;
    std::string linia3Wejscie;
    std::string linia4Wejscie;
    std::string linia5Wejscie;
    std::string linia6Wejscie;
    std::string linia7Wejscie;

    std::string linia1Wyjscie;
    std::string linia2Wyjscie;
    std::string linia3Wyjscie;
    std::string linia4Wyjscie;
    std::string linia5Wyjscie;
    std::string linia6Wyjscie;
    std::string linia7Wyjscie;

    std::fstream plik;
    std::fstream pomocniczy1(plik_pomocniczy1.c_str(), std::fstream::in | std::fstream::out);
    std::fstream pomocniczy2(plik_pomocniczy2.c_str(), std::fstream::in | std::fstream::out | std::fstream::trunc);

    bool przeniesienie = false;
    Dane data1;
    Dane data2;

    while (1)
    {
        std::getline(pomocniczy1, linia1Wejscie);
        if (pomocniczy1.eof())
        {
            break;
        }
        std::getline(pomocniczy1, linia2Wejscie);
        std::getline(pomocniczy1, linia3Wejscie);
        std::getline(pomocniczy1, linia4Wejscie);
        std::getline(pomocniczy1, linia5Wejscie);
        std::getline(pomocniczy1, linia6Wejscie);
        std::getline(pomocniczy1, linia7Wejscie);

        przeniesienie = true;
        plik.open(nazwa_pliku.c_str(), std::fstream::in | std::fstream::out);
        do
        {
            std::getline(plik, linia1Wyjscie);
            if (plik.eof())
            {
                break;
            }
            std::getline(plik, linia2Wyjscie);
            std::getline(plik, linia3Wyjscie);
            std::getline(plik, linia4Wyjscie);
            std::getline(plik, linia5Wyjscie);
            std::getline(plik, linia6Wyjscie);
            std::getline(plik, linia7Wyjscie);

            if (linia1Wejscie == linia1Wyjscie &&
                linia2Wejscie == linia2Wyjscie &&
                linia3Wejscie == linia3Wyjscie &&
                linia4Wejscie == linia4Wyjscie &&
                linia5Wejscie == linia5Wyjscie &&
                linia6Wejscie == linia6Wyjscie &&
                linia7Wejscie == linia7Wyjscie)
            {
                przeniesienie = false;
                break;
            }
        } while (1);
        plik.close();

        if (przeniesienie)
        {
            plik.open(nazwa_pliku.c_str(), std::fstream::in | std::fstream::out | std::fstream::app);

            plik << "\n";
            plik << linia1Wejscie << "\n";
            plik << linia2Wejscie << "\n";
            plik << linia3Wejscie << "\n";
            plik << linia4Wejscie << "\n";
            plik << linia5Wejscie << "\n";
            plik << linia6Wejscie << "\n";
            plik << linia7Wejscie;
            plik.close();
        }
        else
        {
            if (pomocniczy2.tellg() != 0)
            {
                pomocniczy2 << "\n";
            }
            pomocniczy2 << linia1Wejscie << "\n";
            pomocniczy2 << linia2Wejscie << "\n";
            pomocniczy2 << linia3Wejscie << "\n";
            pomocniczy2 << linia4Wejscie << "\n";
            pomocniczy2 << linia5Wejscie << "\n";
            pomocniczy2 << linia6Wejscie << "\n";
            pomocniczy2 << linia7Wejscie;
        }
    }

    pomocniczy1.close();
    pomocniczy2.close();

    pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::in | std::fstream::out | std::fstream::trunc);
    pomocniczy2.open(plik_pomocniczy2.c_str(), std::fstream::in | std::fstream::out);
    while (1)
    {
        std::getline(pomocniczy2, linia1Wejscie);
        if (pomocniczy2.eof())
        {
            break;
        }
        std::getline(pomocniczy2, linia2Wejscie);
        std::getline(pomocniczy2, linia3Wejscie);
        std::getline(pomocniczy2, linia4Wejscie);
        std::getline(pomocniczy2, linia5Wejscie);
        std::getline(pomocniczy2, linia6Wejscie);
        std::getline(pomocniczy2, linia7Wejscie);

        if (pomocniczy1.tellg() != 0)
        {
            pomocniczy1 << "\n";
        }
        pomocniczy1 << linia1Wejscie << "\n";
        pomocniczy1 << linia2Wejscie << "\n";
        pomocniczy1 << linia3Wejscie << "\n";
        pomocniczy1 << linia4Wejscie << "\n";
        pomocniczy1 << linia5Wejscie << "\n";
        pomocniczy1 << linia6Wejscie << "\n";
        pomocniczy1 << linia7Wejscie;
    }

    pomocniczy1.close();
    pomocniczy2.close();
}

void SortCount(std::string nasz_plik, std::string plik_pomocniczy1, std::string plik_pomocniczy2)
{
    std::fstream sprawdzCzyPusty(nasz_plik.c_str(), std::fstream::in | std::fstream::out | std::fstream::ate);
    if (!sprawdzCzyPusty.good() && sprawdzCzyPusty.tellg() == 0)
    {
        sprawdzCzyPusty.close();
        return;
    }
    sprawdzCzyPusty.close();

unsigned int pomocniczy_int = 0;

    bool czy_zmieniamy;
    std::string linijka;
    std::fstream plik;
    std::fstream pomocniczy1;
    std::fstream pomocniczy2;
    int suma1;
    int suma2;

    Dane sprawdzana;
    Dane porownywana;

    do
    {
        czy_zmieniamy = false;

        plik.open(nasz_plik.c_str(), std::fstream::in);
        pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::out | std::fstream::trunc);

        if (!plik.good())
        {
            plik.close();
            return;
        }

        if (!pomocniczy1.good())
        {
            pomocniczy1.close();
            return;
        }

        if (ladujDane(plik, sprawdzana))
        {
            while ((plik >> porownywana.liczba) &&
    (plik.ignore(2, '\n')) &&
    (std::getline(plik, porownywana.napis)) &&
    (std::getline(plik, porownywana.znak)) &&
    (plik >> porownywana.skladowa1.nasz_bool >> pomocniczy_int >> porownywana.skladowa1.nasz_float) &&
    (porownywana.skladowa1.nasz_uchar = pomocniczy_int) &&
    (plik >> porownywana.skladowa2.nasz_bool >> pomocniczy_int >> porownywana.skladowa2.nasz_float) &&
    (porownywana.skladowa2.nasz_uchar = pomocniczy_int) &&
    (plik >> porownywana.skladowa3.nasz_bool >> pomocniczy_int >> porownywana.skladowa3.nasz_float) &&
    (porownywana.skladowa3.nasz_uchar = pomocniczy_int) &&
    (plik >> porownywana.skladowa4.nasz_bool >> pomocniczy_int >> porownywana.skladowa4.nasz_float) &&
    (porownywana.skladowa4.nasz_uchar = pomocniczy_int))
            {
                if (sprawdzana.liczba < porownywana.liczba)
                {
                    ZapiszDane(pomocniczy1, porownywana);
                    czy_zmieniamy = true;
                }
                else
                {
                    ZapiszDane(pomocniczy1, sprawdzana);
                    sprawdzana = porownywana;
                }
            }

            ZapiszDane(pomocniczy1, sprawdzana);
        }

        plik.close();
        pomocniczy1.close();

        if (czy_zmieniamy)
        {
            // otwieramy, ĹĽeby byÄ‡ na poczÄ…tku plikĂłw
            pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::in);
            plik.open(nasz_plik.c_str(), std::fstream::out | std::fstream::trunc);

            if (!plik.good())
            {
                plik.close();
                return;
            }

            if (!pomocniczy1.good())
            {
                pomocniczy1.close();
                return;
            }

            std::string bufor;

            while (std::getline(pomocniczy1, bufor))
            {
                plik << bufor << '\n';
            }

            plik.close();
            pomocniczy1.close();
        }

    } while (czy_zmieniamy);

    plik.open(nasz_plik.c_str(), std::fstream::in | std::fstream::out);

    Dane data1;
    Dane data2;

    if ( (plik >> data1.liczba) &&
    (plik.ignore(2, '\n')) &&
    (std::getline(plik, data1.napis)) &&
    (std::getline(plik, data1.znak)) &&
    (plik >> data1.skladowa1.nasz_bool >> pomocniczy_int >> data1.skladowa1.nasz_float) &&
    (data1.skladowa1.nasz_uchar = pomocniczy_int) &&
    (plik >> data1.skladowa2.nasz_bool >> pomocniczy_int >> data1.skladowa2.nasz_float) &&
    (data1.skladowa2.nasz_uchar = pomocniczy_int) &&
    (plik >> data1.skladowa3.nasz_bool >> pomocniczy_int >> data1.skladowa3.nasz_float) &&
    (data1.skladowa3.nasz_uchar = pomocniczy_int) &&
    (plik >> data1.skladowa4.nasz_bool >> pomocniczy_int >> data1.skladowa4.nasz_float) &&
    (data1.skladowa4.nasz_uchar = pomocniczy_int))
    {
        pomocniczy2.open(plik_pomocniczy2.c_str(), std::fstream::in | std::fstream::out | std::fstream::trunc);

        if (!pomocniczy2.good())
        {
            pomocniczy2.close();
            return;
        }

        int licznik = 1;
        int liczba = data1.liczba; 
     
        while (
   (plik >> data1.liczba) &&
    (plik.ignore(2, '\n')) &&
    (std::getline(plik, data1.napis)) &&
    (std::getline(plik, data1.znak)) &&
    (plik >> data1.skladowa1.nasz_bool >> pomocniczy_int >> data1.skladowa1.nasz_float) &&
    (data1.skladowa1.nasz_uchar = pomocniczy_int) &&
    (plik >> data1.skladowa2.nasz_bool >> pomocniczy_int >> data1.skladowa2.nasz_float) &&
    (data1.skladowa2.nasz_uchar = pomocniczy_int) &&
    (plik >> data1.skladowa3.nasz_bool >> pomocniczy_int >> data1.skladowa3.nasz_float) &&
    (data1.skladowa3.nasz_uchar = pomocniczy_int) &&
    (plik >> data1.skladowa4.nasz_bool >> pomocniczy_int >> data1.skladowa4.nasz_float) &&
    (data1.skladowa4.nasz_uchar = pomocniczy_int))
        {
            if (data1.liczba == liczba)
            {
                licznik++;
            }
            else
            {
                pomocniczy2 << liczba << " " << licznik << std::endl;
                liczba = data1.liczba;
                licznik = 1;
            }
        }
        pomocniczy2 << liczba << " " << licznik << std::endl;
        pomocniczy2.close();
        plik.close();

        do
        {
            czy_zmieniamy = false;

            ZliczaneLiczby sprawdzana;
            ZliczaneLiczby porownywana;

            pomocniczy2.open(plik_pomocniczy2.c_str(), std::fstream::in);
            pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::out | std::fstream::trunc);

            if (!pomocniczy1.good())
            {
                pomocniczy1.close();
                return;
            }

            if (!pomocniczy2.good())
            {
                pomocniczy2.close();
                return;
            }

            if (ladujDaneZliczajace(pomocniczy2, sprawdzana))
            {
                while (ladujDaneZliczajace(pomocniczy2, porownywana))
                {
                    if (sprawdzana.ilosc < porownywana.ilosc)
                    {
                        ZapiszDaneZliczajace(pomocniczy1, porownywana);
                        czy_zmieniamy = true;
                    }
                    else
                    {
                        ZapiszDaneZliczajace(pomocniczy1, sprawdzana);
                        sprawdzana = porownywana;
                    }
                }

                ZapiszDaneZliczajace(pomocniczy1, sprawdzana);
            }

            pomocniczy2.close();
            pomocniczy1.close();

            if (czy_zmieniamy)
            {
                // otwieramy, ĹĽeby byÄ‡ na poczÄ…tku plikĂłw
                pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::in);
                pomocniczy2.open(plik_pomocniczy2.c_str(), std::fstream::out | std::fstream::trunc);

                if (!pomocniczy1.good())
                {
                    pomocniczy1.close();
                    return;
                }

                if (!pomocniczy2.good())
                {
                    pomocniczy2.close();
                    return;
                }

                std::string bufor;

                while (std::getline(pomocniczy1, bufor))
                {
                    pomocniczy2 << bufor << '\n';
                }

                pomocniczy2.close();
                pomocniczy1.close();
            }

        } while (czy_zmieniamy);

        pomocniczy2.open(plik_pomocniczy2.c_str(), std::fstream::in | std::fstream::out);
        pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::in | std::fstream::out | std::fstream::trunc);

        if (!pomocniczy1.good())
        {
            pomocniczy1.close();
            return;
        }

        if (!pomocniczy2.good())
        {
            pomocniczy2.close();
            return;
        }

        while (pomocniczy2 >> liczba >> licznik)
        {
            plik.open(nasz_plik.c_str(), std::fstream::in);

            if (!plik.good())
            {
                plik.close();
                return;
            }

            while ( (plik >> data1.liczba) &&
    (plik.ignore(2, '\n')) &&
    (std::getline(plik, data1.napis)) &&
    (std::getline(plik, data1.znak)) &&
    (plik >> data1.skladowa1.nasz_bool >> pomocniczy_int >> data1.skladowa1.nasz_float) &&
    (data1.skladowa1.nasz_uchar = pomocniczy_int) &&
    (plik >> data1.skladowa2.nasz_bool >> pomocniczy_int >> data1.skladowa2.nasz_float) &&
    (data1.skladowa2.nasz_uchar = pomocniczy_int) &&
    (plik >> data1.skladowa3.nasz_bool >> pomocniczy_int >> data1.skladowa3.nasz_float) &&
    (data1.skladowa3.nasz_uchar = pomocniczy_int) &&
    (plik >> data1.skladowa4.nasz_bool >> pomocniczy_int >> data1.skladowa4.nasz_float) &&
    (data1.skladowa4.nasz_uchar = pomocniczy_int))
            {
                if (data1.liczba == liczba)
                {
                    pomocniczy1
           << data1.liczba << '\n'
           << data1.napis << '\n'
           << data1.znak << '\n'
           << data1.skladowa1.nasz_bool << ' ' << static_cast<int>(data1.skladowa1.nasz_uchar) << ' ' << data1.skladowa1.nasz_float << '\n'
           << data1.skladowa2.nasz_bool << ' ' << static_cast<int>(data1.skladowa2.nasz_uchar) << ' ' << data1.skladowa2.nasz_float << '\n'
           << data1.skladowa3.nasz_bool << ' ' << static_cast<int>(data1.skladowa3.nasz_uchar) << ' ' << data1.skladowa3.nasz_float << '\n'
           << data1.skladowa4.nasz_bool << ' ' << static_cast<int>(data1.skladowa4.nasz_uchar) << ' ' << data1.skladowa4.nasz_float << '\n';
                }
            }

            plik.close();
        }

        pomocniczy1.close();
        pomocniczy2.close();

        //
        pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::in | std::fstream::out);
        plik.open(nasz_plik.c_str(), std::fstream::in | std::fstream::out | std::fstream::trunc);

        if (!pomocniczy1.good())
        {
            pomocniczy1.close();
            return;
        }

        if (!plik.good())
        {
            plik.close();
            return;
        }

        if(plik && pomocniczy1)
        {
            std::string kopiowanaLinia = "";
            while (std::getline(pomocniczy1, kopiowanaLinia))
            {
                plik << kopiowanaLinia << '\n';
                if(pomocniczy1.eof())
                {
                    return;
                }
            }
        }
        else
        {
            plik.close();
            pomocniczy1.close();
            return;
        }
        plik.close();
        pomocniczy1.close();

        bool zamianka;

       do
        {
            zamianka = false;

            plik.open(nasz_plik.c_str(), std::fstream::in | std::fstream::out);
            pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::in | std::fstream::out | std::fstream::trunc);

            if (!pomocniczy1.good())
            {
                pomocniczy1.close();
                return;
            }

            if (!plik.good())
            {
                plik.close();
                return;
            }

            if ( (plik >> data1.liczba) &&
    (plik.ignore(2, '\n')) &&
    (std::getline(plik, data1.napis)) &&
    (std::getline(plik, data1.znak)) &&
    (plik >> data1.skladowa1.nasz_bool >> pomocniczy_int >> data1.skladowa1.nasz_float) &&
    (data1.skladowa1.nasz_uchar = pomocniczy_int) &&
    (plik >> data1.skladowa2.nasz_bool >> pomocniczy_int >> data1.skladowa2.nasz_float) &&
    (data1.skladowa2.nasz_uchar = pomocniczy_int) &&
    (plik >> data1.skladowa3.nasz_bool >> pomocniczy_int >> data1.skladowa3.nasz_float) &&
    (data1.skladowa3.nasz_uchar = pomocniczy_int) &&
    (plik >> data1.skladowa4.nasz_bool >> pomocniczy_int >> data1.skladowa4.nasz_float) &&
    (data1.skladowa4.nasz_uchar = pomocniczy_int))
            {
                while ( (plik >> data2.liczba) &&
    (plik.ignore(2, '\n')) &&
    (std::getline(plik, data2.napis)) &&
    (std::getline(plik, data2.znak)) &&
    (plik >> data2.skladowa1.nasz_bool >> pomocniczy_int >> data2.skladowa1.nasz_float) &&
    (data2.skladowa1.nasz_uchar = pomocniczy_int) &&
    (plik >> data2.skladowa2.nasz_bool >> pomocniczy_int >> data2.skladowa2.nasz_float) &&
    (data2.skladowa2.nasz_uchar = pomocniczy_int) &&
    (plik >> data2.skladowa3.nasz_bool >> pomocniczy_int >> data2.skladowa3.nasz_float) &&
    (data2.skladowa3.nasz_uchar = pomocniczy_int) &&
    (plik >> data2.skladowa4.nasz_bool >> pomocniczy_int >> data2.skladowa4.nasz_float) &&
    (data2.skladowa4.nasz_uchar = pomocniczy_int))
                {
                    suma1 = (data1.skladowa1.nasz_uchar + data1.skladowa2.nasz_uchar + data1.skladowa3.nasz_uchar + data1.skladowa4.nasz_uchar) % 256;
                    suma2 = (data2.skladowa1.nasz_uchar + data2.skladowa2.nasz_uchar + data2.skladowa3.nasz_uchar + data2.skladowa4.nasz_uchar) % 256;

                    if (data1.liczba == data2.liczba && suma1 < suma2)
                    {
                       pomocniczy1
           << data2.liczba << '\n'
           << data2.napis << '\n'
           << data2.znak << '\n'
           << data2.skladowa1.nasz_bool << ' ' << static_cast<int>(data2.skladowa1.nasz_uchar) << ' ' << data2.skladowa1.nasz_float << '\n'
           << data2.skladowa2.nasz_bool << ' ' << static_cast<int>(data2.skladowa2.nasz_uchar) << ' ' << data2.skladowa2.nasz_float << '\n'
           << data2.skladowa3.nasz_bool << ' ' << static_cast<int>(data2.skladowa3.nasz_uchar) << ' ' << data2.skladowa3.nasz_float << '\n'
           << data2.skladowa4.nasz_bool << ' ' << static_cast<int>(data2.skladowa4.nasz_uchar) << ' ' << data2.skladowa4.nasz_float << '\n';
                        zamianka = true;
                    }
                    else
                    {
                         pomocniczy1
           << data1.liczba << '\n'
           << data1.napis << '\n'
           << data1.znak << '\n'
           << data1.skladowa1.nasz_bool << ' ' << static_cast<int>(data1.skladowa1.nasz_uchar) << ' ' << data1.skladowa1.nasz_float << '\n'
           << data1.skladowa2.nasz_bool << ' ' << static_cast<int>(data1.skladowa2.nasz_uchar) << ' ' << data1.skladowa2.nasz_float << '\n'
           << data1.skladowa3.nasz_bool << ' ' << static_cast<int>(data1.skladowa3.nasz_uchar) << ' ' << data1.skladowa3.nasz_float << '\n'
           << data1.skladowa4.nasz_bool << ' ' << static_cast<int>(data1.skladowa4.nasz_uchar) << ' ' << data1.skladowa4.nasz_float << '\n';
                        data1 = data2;
                    }
                }

                 pomocniczy1
           << data1.liczba << '\n'
           << data1.napis << '\n'
           << data1.znak << '\n'
           << data1.skladowa1.nasz_bool << ' ' << static_cast<int>(data1.skladowa1.nasz_uchar) << ' ' << data1.skladowa1.nasz_float << '\n'
           << data1.skladowa2.nasz_bool << ' ' << static_cast<int>(data1.skladowa2.nasz_uchar) << ' ' << data1.skladowa2.nasz_float << '\n'
           << data1.skladowa3.nasz_bool << ' ' << static_cast<int>(data1.skladowa3.nasz_uchar) << ' ' << data1.skladowa3.nasz_float << '\n'
           << data1.skladowa4.nasz_bool << ' ' << static_cast<int>(data1.skladowa4.nasz_uchar) << ' ' << data1.skladowa4.nasz_float << '\n';
            }

            plik.close();
            pomocniczy1.close();

            if (zamianka)
            {
                //
                pomocniczy1.open(plik_pomocniczy1.c_str(), std::fstream::in | std::fstream::out);
                plik.open(nasz_plik.c_str(), std::fstream::in | std::fstream::out);

                if (!pomocniczy1.good())
                {
                    pomocniczy1.close();
                    return;
                }

                if (!plik.good())
                {
                    plik.close();
                    return;
                }

                while (std::getline(pomocniczy1, linijka))
                {
                    plik << linijka << '\n';
                }
                plik.close();
                pomocniczy1.close();
                //
            }

        } while (zamianka);
        
    }
    else
    {
        plik.close();
    }
}

