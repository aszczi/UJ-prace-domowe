// Joanna Szewczyk
#include <iostream>

// zabezpieczyc przed tablica zero!!!

// jak jest funkcja logiczna to chyba boolem trzeba true or false

// voidy czy inty

//-----------------------------------------------------add--------------------------------------------------------

void Add(int liczba, int tab[])
{
    if ((liczba >= 1) && (liczba <= 4095))
    {
        int i = 0;

        while (tab[i] != -1)
        {
            if (tab[i] < liczba)
            {
                i++;
            }

            if (tab[i] == liczba)
            {
                break;
            }

            if (tab[i] > liczba)
            {
                int tmp = 0;
                while (tab[i] != -1)
                {
                    tmp = tab[i];
                    tab[i] = liczba;
                    liczba = tmp;
                    i++;
                }
                tab[i] = liczba;
                tab[i + 1] = -1;
                i++;
                break;
            }
            if (tab[i] == -1)
            {
                tab[i] = liczba;
                tab[i + 1] = -1;
            }
        }
        int j = 0;
        if (tab[j] == -1)
        {
            tab[j] = liczba;
            tab[j + 1] = -1;
        }
    }
}

//--------------------------------------------------create-----------------------------------------------------

void Create(int ilosc_elementow, int tab_wejsciowy[], int tab_wyjsciowy[])
{
    // nie mozna dodatkowych tablic!!!!!!!!!!!!!!!!!!!!!!!!
    int indeks = 0;
    int i = 0;
    while (i < ilosc_elementow)
    {
        if ((tab_wejsciowy[i] > 0) && (tab_wejsciowy[i] < 4096))
        {

            int czy_tak = 0;
            int j = 0;
            while (j < indeks)
            {
                if (tab_wejsciowy[i] == tab_wyjsciowy[j])
                {
                    czy_tak++;
                }
                j++;
            }
            if (czy_tak == 0)
            {
                tab_wyjsciowy[indeks] = tab_wejsciowy[i];
                indeks++;
            }
        }

        i++;
    }
    tab_wyjsciowy[indeks] = -1;

    // sortowanie!!!!!!!!!!!!!
    int tmp;
    int k = 0;
    if (tab_wyjsciowy[0] != -1)
    {
        while (tab_wyjsciowy[k + 1] != -1)
        {
            int l = 0;
            int m = l + 1;
            while (tab_wyjsciowy[l + 1] != -1)
            {
                if (tab_wyjsciowy[l] > tab_wyjsciowy[l + 1])
                {
                    tmp = tab_wyjsciowy[l];
                    tab_wyjsciowy[l] = tab_wyjsciowy[l + 1];
                    tab_wyjsciowy[l + 1] = tmp;
                }
                l++;
            }
            k++;
        }
    }
}

//--------------------------------------------complement----------------------------------------------------
// juz dziala
void Complement(int wejscie[], int wyjscie[]) // zrobiona // zamienilam je!!!!!
{                                             // chyba powinnam sprawdzic czzy wartosci tablicy zawieraja sie w zakresie

    int k = 1;
    int indeks = 0;
    while (k < 4096)
    {
        int i = 0;
        int czy_tak = 0;
        while (wejscie[i] != -1)
        {
            if (wejscie[i] == k)
            {
                czy_tak++;
                break;
            }

            i++;
        }
        if (czy_tak == 0)
        {
            wyjscie[indeks] = k;
            indeks++;
        }
        k++;
    }
    wyjscie[indeks] = -1; // tu juz nie trzeba sortowacc
}

//--------------------------------------------------union-------------------------------------------------------

void Union(int tab1[], int tab2[], int tab_suma[])
{
    // int i = 0;

    int indeks = 0;
    // dodajemy cala pierwsza tablice do sumy

    for (int j = 1; j < 4096; j++)
    {
        int czy_tak = 0;
        int i = 0;
        while (tab1[i] != -1)
        {

            if (tab1[i] == j)
            {
                czy_tak++;
            }
            i++;
        }
        int k = 0;
        while (tab2[k] != -1)
        {
            if (tab2[k] == j)
            {
                czy_tak++;
            }
            k++;
        }
        if (czy_tak > 0)
        {

            tab_suma[indeks] = j;
            indeks++;
        }
    }
    tab_suma[indeks] = -1; // posortowane juz sa elementy
}

//----------------------------------------------intersection-----------------------------------------------------

void Intersection(int tab1[], int tab2[], int tab_cz_wsp[])
{
    int i = 0;

    int indeks = 0;

    while (tab1[i] != -1)
    {
        int k = 0;
        while (tab1[k] != -1)
        {
            if (tab1[i] == tab2[k])
            {

                tab_cz_wsp[indeks] = tab1[i];
                indeks++;
            }
            k++;
        }
        i++;
    }

    tab_cz_wsp[indeks] = -1; // zwrocona juz ladnie, nie trzeba sortowac
}

//-----------------------------------------------difference----------------------------------------------------

void Difference(int odjemna[], int odjemnik[], int roznica[])
{
    // odjemna to ta od ktorej odejmujemy
    // odjemnik to to co odejmujemy
    int indeks = 0;
    int i = 0;
    while (odjemna[i] != -1)
    {
        int czy_jest_identico = 0;
        int k = 0;
        while (odjemnik[k] != -1)
        {
            if (odjemna[i] == odjemnik[k])
            {

                czy_jest_identico++;
            }
            k++;
        }
        if (czy_jest_identico == 0)
        {
            roznica[indeks] = odjemna[i];
            indeks++;
        }
        i++;
    }
    roznica[indeks] = -1;

    // juz to cale jest posortowane
}

//-----------------------------------------------Symmetric-----------------------------------------------------

void Symmetric(int tab1[], int tab2[], int tab_roznica[])
{

    int i = 0;
    int k = 0;
    int indeks = 0;
    int czy_tak = 0;
    while (tab1[i] != -1)
    {
        czy_tak = 0;

        while (tab2[k] != -1)
        {
            if (tab1[i] == tab2[k])
            {
                czy_tak++;
                break;
            }
            else
            {
                k++;
            }
        }
        k = 0;
        if (czy_tak == 0)
        {
            tab_roznica[indeks] = tab1[i];
            indeks++;
        }

        i++;
    }

    i = 0;
    k = 0;
    czy_tak = 0;
    while (tab2[i] != -1)
    {
        czy_tak = 0;
        while (tab1[k] != -1)
        {
            if (tab2[i] == tab1[k])
            {
                czy_tak++;
                break;
            }
            else
            {
                k++;
            }
        }
        k = 0;
        if (czy_tak == 0)
        {
            tab_roznica[indeks] = tab2[i];
            indeks++;
        }

        i++;
    }

    tab_roznica[indeks] = -1;

    // sortowanie!!!!!!!!!!!!!!!!!

    int tmp;
    int m = 0;
    if (tab_roznica[0] != -1)
    {
        while (tab_roznica[m + 1] != -1)
        {
            int l = 0;

            while (tab_roznica[l + 1] != -1)
            {
                if (tab_roznica[l] > tab_roznica[l + 1])
                {
                    tmp = tab_roznica[l];
                    tab_roznica[l] = tab_roznica[l + 1];
                    tab_roznica[l + 1] = tmp;
                }
                l++;
            }
            m++;
        }
    }
}

//-------------------------------------------------Subset-------------------------------------------------------

bool Subset(int tab_zawierany[], int tab_zawierajacy[])
{

    int wartosc;
    int n = 0;
    int i = 0;
    while (tab_zawierany[i] != -1)
    {
        // int n = i + 1;
        i++;
    }
    int ilosc_elementow_zawierany = i;

    int m = 0;
    int j = 0;
    while (tab_zawierajacy[j] != -1)
    {
        //  int m = j + 1;
        j++;
    }
    int ilosc_elementow_zawierajacy = j;
    int z = 0;
    if (ilosc_elementow_zawierajacy >= ilosc_elementow_zawierany)
    {

        int k = 0;
        while (tab_zawierany[k] != -1)
        {
            int l = 0;
            while (tab_zawierajacy[l] != -1)
            {
                if (tab_zawierajacy[l] == tab_zawierany[k])
                {
                    z++;
                }
                l++;
            }

            k++;
        }
    }
    else
    {
        z = 0;
    }

    return z == i;
}

//------------------------------------------------empty--------------------------------------------------------

bool Empty(int tab[])
{
    int wartosc = 0;
    if (tab[0] == -1)
    {
        wartosc = 1;
    }
    return wartosc;
}

//---------------------------------------------nonempty--------------------------------------------------------

bool Nonempty(int tab[])
{
    int wartosc = 1;
    if (tab[0] == -1)
    {
        wartosc = 0;
    }
    return wartosc;
}

//-------------------------------------------------equal-------------------------------------------------------

bool Equal(int tab1[], int tab2[])
{

    int k = 0;
    int i = 0;
    int licznik = 0;
    int czy_tak = 1;

    while ((tab1[i] != -1) && (czy_tak == 1))
    {
        k = 0;
        while (tab2[k] != -1)
        {
            licznik = 0;
            if (tab1[i] == tab2[k])
            {
                licznik = 1;
                k++;
                break;
            }
            k++;
        }
        if (licznik != 1)
        {
            czy_tak = 0;
        }
        i = i + 1;
    }
    // wykonujemy to samo dla drugiej tablicy
    i = 0;
    k = 0;
    licznik = 0;

    while ((tab2[i] != -1) && (czy_tak == 1))
    {
        k = 0;
        while (tab1[k] != -1)
        {
            licznik = 0;
            if (tab2[i] == tab1[k])
            {
                licznik = 1;
                k++;
                break;
            }
            k++;
        }
        if (licznik != 1)
        {
            czy_tak = 0;
        }
        i++;
    }
    // sprawdzamy boolem zeby byla logiczna
    return czy_tak == 1;
}

//----------------------------------------------------MinMax---------------------------------------------------

void MinMax(int tab[], int *min, int &max)
{
    if (tab[0] != -1)
    {

        int i = 1;
        max = tab[0];
        *min = tab[0];
        while (tab[i] != -1)
        {

            if ((tab[i] < *min))
            {

                *min = tab[i];
            }

            if ((tab[i] > max))
            {

                max = tab[i];
            }

            i++;
        }

        // max = maximum;
    }
}
//------------------------------------------------------element------------------------------------------------

bool Element(int liczba, int tab[])
{ // dobrzeee
    int i = 0;
    int czy_tak;

    while (tab[i] != -1)
    {
        if (tab[i] != liczba)
        {
            czy_tak = 0;
        }
        if (tab[i] == liczba)
        {
            czy_tak = 1;
            break;
        }
        i++;
        ;
    }

    return czy_tak == 1;
}

//-----------------------------------------------------arithmetic----------------------------------------------

double Arithmetic(int tab[])
{
    int i = 0;
    double suma = 0;
    double srednia = 0.00;
    if (tab[0] != -1)
    {
        while (tab[i] != -1)
        {
            suma += tab[i];
            i++;
        }
        srednia = ((suma) / (i));
    }

    return srednia;
}

//----------------------------------------------------harmonic---------------------------------------------------

double Harmonic(int tab[])
{
    int i = 0.00; // double czy int
    double suma = 0.00;
    double srednia;
    double ilosc_liczb = 0.00;
    if (tab[0] == -1)
    {
        srednia = 1;
    }
    if (tab[0] != -1)
    {
        do
        {
            suma += ((1) / (double)tab[i]);
            i++;
        } while (tab[i] != -1);

        ilosc_liczb = i;
        if (suma != 0)
        {
            srednia = ((ilosc_liczb) / (double)suma);
        }

        if (suma == 0)
        {
            srednia = 0;
        }
    }
    return srednia;
}

//-------------------------------------------------Cardinality--------------------------------------------------

void Cardinality(int tab[], int *moc)
{
    int i = 0;
    int nasza_moc = 0;
    // *moc = 0;
    while (tab[i] != -1)
    {
        nasza_moc++;
        i++;
    }
    // nasza_moc++;
    *moc = nasza_moc;
}

//----------------------------------------------------Prosperities------------------------------------------------

void Properties(int tab[], char ch[], double &sr_arytmetyczna, double *sr_harmoniczna, int &min, int *max, int &moc)
{

    int znak = 0;

    while (ch[znak] != 0)
    {

        if (ch[znak] == 'a')
        {

            int i = 0;
            double suma = 0;
            sr_arytmetyczna = 0.00;
            if (tab[0] != -1)
            {
                while (tab[i] != -1)
                {
                    suma += tab[i];
                    i++;
                }
                sr_arytmetyczna = ((suma) / (i));
            }

           // sr_arytmetyczna = sr_arytmetyczna;
           znak++;
        }

        if (ch[znak] == 'h')
        {
            int i = 0.00; // double czy int
            double suma = 0.00;
          //  double sr_harmoniczna;
            double ilosc_liczb = 0.00;
            if (tab[0] == -1)
            {
                *sr_harmoniczna = 1;
            }
            if (tab[0] != -1)
            {
                do
                {
                    suma += ((1) / (double)tab[i]);
                    i++;
                } while (tab[i] != -1);

                ilosc_liczb = i;
                if (suma != 0)
                {
                    *sr_harmoniczna = ((ilosc_liczb) / (double)suma);
                }

                if (suma == 0)
                {
                    *sr_harmoniczna = 0;
                }
            }
            znak++;
           // *sr_harmoniczna = sr_harmoniczna;
        }

        if (ch[znak] == 'm')
        {

            if (tab[0] != -1)
            {

                int i = 1;
                *max = tab[0];
                min = tab[0];
                while (tab[i] != -1)
                {

                    if ((tab[i] < min))
                    {

                        min = tab[i];
                    }

                    if ((tab[i] > *max))
                    {

                        *max = tab[i];
                    }

                    i++;
                }

                // max = maximum;
            }
            znak++;
        }

        if (ch[znak] == 'c')
        {
            int i = 0;
            int nasza_moc = 0;
            // *moc = 0;
            while (tab[i] != -1)
            {
                nasza_moc++;
                i++;
            }
            // nasza_moc++;
            moc = nasza_moc;
            znak++;
        }
    }
}